<?php
namespace app\Providers\ThemesRenderProviders;

/*
|--------------------------------------------------------------------------------
| Themes Render Providers [ThemesRenderProviders]
|--------------------------------------------------------------------------------
|
|
|
*/

class ThemesRenderProviders {
  
  static function render() {

  }
}
?>