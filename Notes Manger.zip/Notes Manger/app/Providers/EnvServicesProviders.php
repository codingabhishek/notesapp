<?php
namespace app\Providers\EnvServicesProviders;

/*
|----------------------------------------------------------------
| Env Services Providers class [EnvServicesProviders]
|----------------------------------------------------------------
|
| EnvServicesProviders provide the full setup of environments
| variables with securely EnvServicesProviders read .env
| and .config file and clean all comment and set all value
| in $_SERVER & $_ENV EnvServicesProviders provide extra
| usefull features like getBool, getInteger, getArray methods
|
*/

class EnvServicesProviders {

  private static $rparser = "/^(\[\s*)((\"|\')(.*)(\"|\')(\s*\=\>\s*)(\"|\')(.*)(\"|\')(,*))(\s*\])$/";
  private static object $EnvServicesProviders;
  private static bool $isSafeLoad=false;
  private static array $envDataStorage;
  private static $isImmutable=false;
  private static string $envDestination;
  private static string $supportExe="/\.(?:env|config)$/";

  public function load() {
    if (!self::$isImmutable) return;
    $resources = file(self::$envDestination); # env total lines
    $rcomment = "/(\"|\')(;*)\s*(#.*)$/";
    $rnoComma = "/(;*\s*)(#.*)/";
    $renvdata = "/^(\w+)\=(.*)$/";
    $renvExtracter = "/(\s*#.*)$/";
    
    for ($i=0; $i < count($resources); $i++) {
      $line=$resources[$i];
      if (!preg_match($renvdata, $line, $matched)) {
        continue;
      }

      array_shift($matched); # delete first index

      $envkey = array_shift($matched);
      $envvalue = join("", $matched);

      if (preg_match($renvExtracter, $envvalue, $comments)) {
        $matcher = array_shift($comments);
        preg_match($rcomment, $matcher, $sepradecomment);
        $comment = array_shift($sepradecomment);
        $attach = array_shift($sepradecomment);
        
        // Handle Comments for seprated (\' \") cot env value
        if ($comment) {
          $envvalue = substr($envvalue, 1, -strlen($comment));
        } else {
          $envvalue = preg_replace($rnoComma, "", $envvalue);
        }
      }

      $_SERVER[$envkey] = $_ENV[$envkey] = self::$envDataStorage[$envkey] = $envvalue;
    }
  }

  private static function get($key) {
    return self::$isSafeLoad ? self::$envDataStorage[$key] ?? null : self::$envDataStorage[$key];
  }

  static function getBool($key) {
    if (self::get($key)===null) return;
    return !!self::get($key);
  }

  static function getInteger($key) {
    if (self::get($key)===null) return;
    return intval(self::get($key));
  }

  static function getArray($key) {
    $envvalue = self::get($key);
    $parseEnv = json_decode($envvalue, true) ?? $envvalue;
    $rparser = self::$rparser;

    if ($envvalue===null) return;

    if (!is_array($parseEnv) && preg_match($rparser, $parseEnv)) {
      $parseEnv = str_replace(["[", "=>", "]"], ["{", ":", "}"], $parseEnv);
      $parseEnv = json_decode($parseEnv, true) ?? [$envvalue];
    }
    return is_array($parseEnv) ? $parseEnv : [$parseEnv];
  }

  static function locateEnvFileLocation($source, $root=false) {
    if (preg_match(self::$supportExe, $source)) {
      self::$isImmutable=true;
      $EnvServicesProviders = new static;
      self::$EnvServicesProviders=$EnvServicesProviders;
      $rootdir = $_SERVER["DOCUMENT_ROOT"] . "/";
      $root && ($source=$rootdir.$source);
      $EnvServicesProviders::$envDestination=$source;
    }
    return $EnvServicesProviders;
  }

  public function safeLoad() {
    self::$isSafeLoad=true;
    file_exists(self::$envDestination) && self::$EnvServicesProviders->load();
  }
}
?>