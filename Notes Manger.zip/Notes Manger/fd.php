.BO1Zf4qbZ {
  height: 100%;
  width: 100%;
}
.CGA3xkcxA {
  overflow: hidden;
}
.KrebH1xCG {
  overflow-x: hidden;
}
.YdoDMzzAi {
  overflow-y: hidden;
}
.TitpbAdSN {
  direction: rtl;
}
.AjFA1cELY {
  direction: ltr;
}
.ydNrdEUSf {
  display: flex;
}
.YME4cUU0s {
  align-items: center;
}
.v4iaSbHTz {
  justify-content: center;
}
.exr9QQpyT {
  display: inline-flex;
}
.QPou3Wze0 {
  flex-wrap: nowrap;
}
.fnoDqvqOH {
  justify-content: center;
  display: flex;
  align-items: center;
}
.Eo7E6F84I {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.Futi0rbjU, .align-both-center {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.align-x-center {
  left: 50%;
  transform: translateX(-50%);
}
.align-y-center {
  top: 50%;
  transform: translateY(-50%);
}
.WgUGxPCuV {
  border-radius: 50%;
}
.LuYXzGx6Q {
  text-align: center;
}
.F5OYIlxgO {
  flex: 1;
}
.cit8okVvn {
  flex-grow: 1;
}
.c8J4vhn6R {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.x9rndxQy7 {
  pointer-events: none;
  touch-action: none;
}
.gS4U2qRdo {
  cursor: not-allowed;
}
.KyrjOTDEL {
  cursor: default;
}
.fE6TgekIu {
  cursor: text;
}
.JOrg5y4AV {
  pointer-events: all;
  touch-action: initial;
}
.F9xc60LLZ {
  font-family: inherit;
}
.V25eFR4Lz {
  border: none;
}
.K9NvGXWwj {
  flex-direction: column-reverse;
}
.A6tyEeQ0U {
  position: relative;
}
.Gok2N2nEj {
  position: absolute;
}
.stDgdv64V {
  display: flex;
  flex-direction: column;
}
.PMiBu3q7U {
  right: 0;
  top: 0;
  left: 0;
  bottom: 0;
}
.Xd6G1wnM1 {
  margin: auto;
}
.M9kkyExmG {
  margin: 0 auto;
}
.rgOmUTXB5 {
  margin: auto 0;
}
.Tuw1ayR0q {
  margin-top: auto;
}
.UtElxNphW {
  margin-bottom: auto;
}
.ZIxhge1E1 {
  margin-left: auto;
}
.ZLVyuVQil {
  margin-right: auto;
}
.eCzF3EuiP {
  text-transform: capitalize;
}
.K0Qz1XJ3u {
  text-transform: uppercase;
}
.DyBwOmsE {
  flex-direction: column;
}
.JhHXIjE9B {
  text-transform: lowercase;
}
.J4FO5DQyr {
  right: 0;
}
.g9QmVPFJw {
  top: 0;
}
.CSmLJf {
  right: 0;
}
.YmTgUJgfF {
  bottom: 0;
}
.Q3m1TjFEg {
  width: 100%;
}
.YiVmwrNp2 {
  height: 100%;
}
.ZROFGhuL9 {
  flex-direction: row-reverse;
}
.Ywy5pKll8 {
  justify-content: space-between;
}
.GdiC29Du3 {
  flex-wrap: wrap;
}
.QC1zaKJKC {
  width: -webkit-fill-available;
}
.x50ncvXCb {
  white-space: nowrap;
}
.c9eFY3RS0 {
  line-height: normal;
}
.hidden {
  display: none!important;
}
.visible {
  display: inherit!important;
}
.invisible {
  display: none;
}
.wsnormal {
  white-space: normal;
}
.swDoDxaKt {
  pointer-events: auto;
}
.g00OW6qIq {
  touch-action: none;
}
.czWrKt71F {
  scrollbar-width: 0px;
}
.czWrKt71F::-webkit-scrollbar {
  width: 0px;
}
.EGaSa3sXQ::-webkit-scrollbar {
  height: 0px;
}
.strict * {
  pointer-events: none;
  touch-action: none;
}
.disabled {
  touch-action: none!important;
  cursor: default!important;
  pointer-events: none!important;
}
.hunderline:hover {
  text-decoration: underline;
}



<ul>
            <li class="selected">
              <div class="item-left Eo7E6F84I">
                <div class="textwrap Eo7E6F84I"><span>Toggle Wrap key Mouse Focus</span></div>
              </div>
              <div class="item-right">
                <div class="kbd-shortcut">
                  <kbd>Ctrl</kbd>
                  <span>+</span>
                  <kbd>Alt</kbd>
                  <span>+</span>
                  <kbd>ArrowDown</kbd>
                </div>
                <div class="prompt-setting-icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" class="expect-path" style="width: 16px; height: 16px;"><use xlink:href="/svg/notesmanager.svgall.svg#settings_props"></use></svg>
                </div>
              </div>
            </li>
          </ul>